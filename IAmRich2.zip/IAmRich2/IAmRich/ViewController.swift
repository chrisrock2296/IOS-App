//
//  ViewController.swift
//  IAmRich
//
//  Created by Christian Hartman on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func BTN_Welcome(_ sender: Any) {
        print("Hello World");
    }
}

