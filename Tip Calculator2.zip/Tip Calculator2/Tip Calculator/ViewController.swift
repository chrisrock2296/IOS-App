//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Christian Hartman on 9/7/23.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var TxtBillAmount: UITextField!
    
    @IBOutlet weak var LblTipamount: UILabel!
    
    @IBOutlet weak var DifTipAmout: UISegmentedControl!
    
    @IBAction func BtnCalTip(_ sender: UIButton) {
        
        let userInput = Float(TxtBillAmount.text!)
        
        if userInput == nil {
            // send an alert to user
            let alertController = UIAlertController(title: "Incorect Bill Amout", message: "Bill Amount CANT be Blank", preferredStyle: UIAlertController.Style.alert)
               
               alertController.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
               
               present(alertController,animated: true,completion: nil)
            //exit function
            return
        }
        
        let index : Int = DifTipAmout.selectedSegmentIndex
        
        var TipRate : Float
        
        if index == 0 {
            TipRate = 0.15
        }
        else if index == 1 {
            TipRate = 0.20
        }
        else {
            TipRate = 0.25
        }
        let Tip = userInput! * TipRate
        
        let dispay = String(format:"$%.2f",Tip)
        
        LblTipamount.text = dispay
    }
    //this click away anaything on screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}


