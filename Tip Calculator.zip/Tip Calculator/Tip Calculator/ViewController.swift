//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Christian Hartman on 9/7/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

