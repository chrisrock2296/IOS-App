//
//  ViewController.swift
//  IAmRich
//
//  Created by Christian Hartman on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func BTN_Welcome(_ sender: Any) {
        // print("Hello World"); only to developer
        
        //prints pop up message use this code
        let alertController = UIAlertController(title: "You Must be Rich", message: "Hello there", preferredStyle: UIAlertController.Style.alert)
        
        alertController.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
        
        present(alertController,animated: true,completion: nil)
        
    }
}

