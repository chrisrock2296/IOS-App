//
//  ViewController.swift
//  UserAccounts
//
//  Created by admin on 10/30/23.

import UIKit
import CoreData

var websites: [String] = []
var activeWebsite: String?

class WebsitesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblWebsites: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidDisappear(_ animated: Bool) {
        websites = []
    }

    override func viewDidAppear(_ animated: Bool) {
        fetchWebsites()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return websites.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        var content = cell.defaultContentConfiguration()
        content.text = websites[indexPath.row]
        cell.contentConfiguration = content
        return cell
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            deleteWebsite(at: indexPath.row)
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        activeWebsite = getActiveWebsiteFromName(activeWebsiteName: websites[indexPath.row])
        presentCredentialsViewController()
    }

    func fetchWebsites() {
        websites = []

        var data = [Website]()
        do {
            data = try context.fetch(Website.fetchRequest())
            for existingData in data {
                if existingData.user == activeUser {
                    websites.append(existingData.websiteName!)
                }
            }
        } catch {
        }

        tblWebsites.reloadData()
    }

    func deleteWebsite(at index: Int) {
        var data = [Website]()
        do {
            data = try context.fetch(Website.fetchRequest())
            for existingData in data {
                if existingData.websiteName == websites[index] {
                    context.delete(existingData)
                }
            }
        } catch {
        }

        appDelegate.saveContext()
        websites.remove(at: index)
        tblWebsites.reloadData()
    }

    func getActiveWebsiteFromName(activeWebsiteName: String) -> String {
        var returnURL: String? = nil

        var data = [Website]()
        do {
            data = try context.fetch(Website.fetchRequest())
            for existingData in data {
                if existingData.websiteName == activeWebsiteName {
                    returnURL = existingData.url!
                }
            }
        } catch {
        }

        return returnURL!
    }

    func presentCredentialsViewController() {
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let credentialsViewController: UIViewController = storyboard.instantiateViewController(withIdentifier: "VCCredentials")
        self.present(credentialsViewController, animated: true)
    }
}
