//
//  ViewController.swift
//  UserAccounts
//
//  Created by admin on 10/30/23.

import UIKit
import CoreData

var appDelegate = UIApplication.shared.delegate as! AppDelegate
var context = appDelegate.persistentContainer.viewContext

var activeUser: String?

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        lblStatus?.isHidden = true
    }

    @IBOutlet weak var txtUsername: UITextField!

    @IBOutlet weak var txtPassword: UITextField!

    @IBOutlet weak var lblStatus: UILabel?

    func addNewAccount(newUsername: String, newPassword: String) {
        let newAccount = Account(context: context)
        newAccount.username = newUsername
        newAccount.password = newPassword
        appDelegate.saveContext()
    }

    func userExists(username: String) -> Bool {
        var foundQualification = false
        var data = [Account]()

        do {
            try data = context.fetch(Account.fetchRequest())

            for existingData in data {
                let existingUsername = existingData.username
                if existingUsername == username {
                    foundQualification = true
                }
            }
        } catch {}

        return foundQualification
    }

    func statusLabelAccountExists(username: String) {
        lblStatus?.isHidden = false
        lblStatus?.textColor = .systemRed
        lblStatus?.text = "Account \(username) exists."
    }

    func statusLabelInvalid() {
        lblStatus?.isHidden = false
        lblStatus?.textColor = .systemRed
        lblStatus?.text = "Please try again."
    }

    func statusLabelSuccessfullyCreated() {
        lblStatus?.isHidden = false
        lblStatus?.textColor = .systemGreen
        lblStatus?.text = "Account created!"
    }

    func clearLogin() {
        txtUsername.text = ""
        txtPassword.text = ""
    }

    @IBAction func btnCreateNewAccount(_ sender: Any) {
        let username = txtUsername.text
        let password = txtPassword.text

        if username != nil && username != "" && password != nil && password != "" && !userExists(username: username!) {
            addNewAccount(newUsername: username!, newPassword: password!)
            statusLabelSuccessfullyCreated()
        } else {
            if userExists(username: username!) {
                statusLabelAccountExists(username: username!)
            } else {
                statusLabelInvalid()
            }
        }

        clearLogin()
    }

    @IBAction func btnSignIn(_ sender: Any) {
        var data = [Account]()
        let username = txtUsername.text
        let password = txtPassword.text

        if username != nil && username != "" && password != nil && password != "" {
            do {
                try data = context.fetch(Account.fetchRequest())

                for existingData in data {
                    if existingData.username == username! && existingData.password == password! {
                        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                        let viewControllerTabBar: UIViewController = storyboard.instantiateViewController(withIdentifier: "TBCCredentials") as UIViewController
                        self.present(viewControllerTabBar, animated: true)

                        activeUser = username!

                        clearLogin()
                        return
                    }
                }
            } catch {}
        }

        clearLogin()
        statusLabelInvalid()
    }
}
