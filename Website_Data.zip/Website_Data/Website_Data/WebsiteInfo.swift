import UIKit
import CoreData

class WebsiteInfo: UIViewController {
    @IBOutlet weak var lblWebsiteName: UILabel!
    @IBOutlet weak var txtViewURL: UITextView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblPassword: UILabel!
    
    var activeURL = activeWebsite

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updateUI()
    }

    func updateUI() {
        var data = [Website]()
        
        do {
            data = try context.fetch(Website.fetchRequest())
            
            for existingData in data {
                if existingData.user == activeUser && existingData.url == activeWebsite {
                    lblWebsiteName.text = existingData.websiteName
                    txtViewURL.text = existingData.url
                    lblUsername.text = existingData.username
                    lblPassword.text = existingData.password
                }
            }
        } catch {
        }
    }
}
