import UIKit
import CoreData

class AddNewViewCont: UIViewController {
    @IBOutlet weak var txtWebsiteName: UITextField!
    @IBOutlet weak var txtURL: UITextField!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet var lblStatus: UILabel!
    @IBOutlet weak var btnGenerateAPassword: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        lblStatus.isHidden = true
        btnGenerateAPassword.isHidden = true
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        btnGenerateAPassword.isHidden = true
    }

    @IBAction func btnGeneratePassword(_ sender: Any) {
        txtPassword.text = generateRandomPassword()
    }

    @IBAction func txtPasswordEditingBegan(_ sender: Any) {
        btnGenerateAPassword.isHidden = false
    }

    @IBAction func btnAddWebsite(_ sender: Any) {
        addNewWebsite()
    }

    func generateRandomPassword() -> String {
        let characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&*?"
        let passwordLength = 10 // You can adjust the desired password length

        var password = ""
        for _ in 0..<passwordLength {
            let randomIndex = Int(arc4random_uniform(UInt32(characters.count)))
            let character = characters[characters.index(characters.startIndex, offsetBy: randomIndex)]
            password.append(character)
        }

        return password
    }

    func statusLabelEmptyFields() {
        lblStatus.isHidden = false
        lblStatus.textColor = .systemRed
        lblStatus.text = "Please fill in all spaces."
    }

    func statusLabelNotValidURL() {
        lblStatus.isHidden = false
        lblStatus.textColor = .systemRed
        lblStatus.text = "Please enter a real URL."
    }

    func clearTextFields() {
        txtWebsiteName.text = ""
        txtURL.text = ""
        txtUsername.text = ""
        txtPassword.text = ""
    }

    func isValidURL(urlString: String) -> Bool {
        let urlRegEx = #"^(https?://)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,6}(/\S*)?$"#
        let urlTest = NSPredicate(format: "SELF MATCHES %@", urlRegEx)
        return urlTest.evaluate(with: urlString)
    }

    func addNewWebsite() {
        if let websiteName = txtWebsiteName.text,
           let username = txtUsername.text,
           let password = txtPassword.text,
           let url = txtURL.text {
            if !websiteName.isEmpty, !username.isEmpty, !password.isEmpty, !url.isEmpty {
                if isValidURL(urlString: url) {
                    let newWebsite = Website(context: context)
                    newWebsite.websiteName = websiteName
                    newWebsite.user = activeUser
                    newWebsite.url = url
                    newWebsite.username = username
                    newWebsite.password = password
                    appDelegate.saveContext()
                    self.tabBarController?.selectedIndex = 0
                } else {
                    statusLabelNotValidURL()
                }
            } else {
                statusLabelEmptyFields()
            }
        }
        clearTextFields()
    }
}
